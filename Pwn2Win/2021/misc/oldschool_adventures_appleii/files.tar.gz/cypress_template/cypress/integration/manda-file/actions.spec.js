/// <reference types="cypress" />

context('Actions', () => {
  beforeEach(() => {
    cy.visit('http://apachehost/emulador/apple2js.html')
  })

  // https://on.cypress.io/interacting-with-elements

  it('.type() - type into a DOM element', () => {
    // https://on.cypress.io/type
    cy.get('button[title="Load Disk"]').first().click()
    
    //cy.get('#local_file').attachFile("exibe_texto_na_tela.dsk")
    
    cy.fixture('template.dsk', 'binary')
	  .then(Cypress.Blob.binaryStringToBlob)
	  .then(fileContent => {
	    cy.get('#local_file').attachFile({
	      fileContent,
	      fileName: 'template.dsk',
	    //  mimeType: 'application/octet-stream',
	      encoding: 'utf-8',
	    });
	    
	    
     cy.get('button[aria-label="Open the selected disk"]').click()
    
     cy.scrollTo(0, 0)
    
     cy.wait(50000)
     
     cy.screenshot()
    
   });


 });
  
});
