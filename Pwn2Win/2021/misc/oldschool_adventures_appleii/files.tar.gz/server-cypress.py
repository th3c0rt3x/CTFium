#!/usr/bin/python
# -*- coding: utf-8 -*-

import os, subprocess
import thread
import random
import string
import json
from datetime import datetime
from socket import *

HOST = "0.0.0.0"
PORT = 1337
BUFF = 268
PATH = "/home/stevej/stuff"
CYPRESS = PATH + "/cypress_template"

def createString():
	return ''.join(random.choice(string.ascii_lowercase) for _ in range(10))

def check_pow(solution, randomstr):
	FNULL = open(os.devnull, 'w')
	return subprocess.call(["hashcash", "-cdb25", "-r", randomstr, solution], cwd="/tmp", stdout=FNULL, stderr=subprocess.STDOUT) == 0

def readImg(pathPrincipal, barcodereaderPathCompleto):
	pathFinal = pathPrincipal + "/cypress/screenshots/manda-file/actions.spec.js/"
	os.chdir(pathFinal)
	os.system("mv \"Actions -- .type() - type into a DOM element.png\" qr.png")
	
	os.system("cp -r " + barcodereaderPathCompleto + "/* " + pathFinal)
	
	cmd = "./ReadBarcode"
	output = subprocess.check_output(cmd.split())
	try:
		if output.split("\r\n")[3].split()[1] == "QR_CODE":
			result = " ".join(output.split("\r\n")[4].split()[1:])
			return result
	except:
		return False
	
def executeCmd(cmd):
	os.chdir(PATH + "/secret")
	try:
		p = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
		result = p.communicate()[0]
		return result
	except:
		return False

def prepareFiles(name, IP, payload, pathPrincipal, payloadPathFinal, diskPathCompleto, tokenizePathCompleto, payloadTokenizedPathCompleto, applecmdPathCompleto):

	payload = payload.replace("§", "\n")
	temp = open(payloadPathFinal, "w")
	temp.writelines(payload)
	temp.close()
	
	os.system("python3 " + tokenizePathCompleto + " " + payloadPathFinal + " " + payloadTokenizedPathCompleto)
	
	os.system("java -jar " + applecmdPathCompleto + " -p " + diskPathCompleto + " HELLO BAS 0x801 < " + payloadTokenizedPathCompleto)
	
def takeScreenshot(IP, name, diskPathCompleto, cypressPathCompleto, screenshotsPathCompleto):
	
	os.chdir(cypressPathCompleto)
	os.system("npm run cypress:run")

def finishJob(pathPrincipal):
	os.system("rm -rf " + pathPrincipal + "/*")

def manipulador(clientsock, addr):

	try:
	
		clientsock.settimeout(60)
		randomstr = createString()
		clientsock.send("Send the solution for \"hashcash -mb 25 " + randomstr + "\": ")
		solution = clientsock.recv(BUFF)
		
		if not check_pow(solution.strip(), randomstr):
			clientsock.send("\nInvalid PoW.\n")
			clientsock.close()
			return
	
		try:
			IP = addr[0]
			tempo = datetime.now()
			dia = datetime.today()
			name = IP + "_" + str(tempo.day) + "_" + tempo.strftime("%H_%M_%S")
			
			pathPrincipal = PATH + "/processing/" + IP
			
			if not os.path.exists(pathPrincipal):
				os.system("mkdir " + pathPrincipal)
				
			os.system("cp -r " + CYPRESS + "/* " + pathPrincipal)
			
			diskPathCompleto = pathPrincipal + "/cypress/fixtures/template.dsk"
			fixturesPathCompleto = pathPrincipal + "/cypress/fixtures/"
			payloadPathFinal = pathPrincipal + "/cypress/fixtures/" + name
			payloadTokenizedPathCompleto = pathPrincipal + "/cypress/fixtures/" + name + "-tokenized"
			screenshotsPathCompleto = pathPrincipal + "/cypress/screenshots/manda-file/actions.spec.js/Actions -- .type() - type into a DOM element.png"
			cypressPathCompleto = pathPrincipal
			
			tokenizePathCompleto = PATH + "/tools/tokenize.py"
			applecmdPathCompleto = PATH + "/tools/ac.jar"
			barcodereaderPathCompleto = PATH + "/tools/barcode"
			
			funfouPathCompleto = PATH + "/funfou/" + name
			
			clientsock.settimeout(5)
			clientsock.send("Send your payload here: ")
			
			payload = clientsock.recv(BUFF).strip()
			
			if payload.count("§") > 1:
				clientsock.send("Just 1 line break (§) is allowed!")
				clientsock.close()
				return
				
			clientsock.send("\nWait, processing...\n")
			
			prepareFiles(name, IP, payload, pathPrincipal, payloadPathFinal, diskPathCompleto, tokenizePathCompleto, payloadTokenizedPathCompleto, applecmdPathCompleto)
			takeScreenshot(IP, name, diskPathCompleto, cypressPathCompleto, screenshotsPathCompleto)
			cmd = readImg(pathPrincipal, barcodereaderPathCompleto)
			if cmd:
				result = executeCmd(cmd)
				if result:
					os.system("mv " + payloadPathFinal + " " + funfouPathCompleto)
					clientsock.send(result)
				else:
					clientsock.send("\nInvalid linux command: " + cmd + "\n")
			else:
				clientsock.send("\nNot a valid QR!\n")
		
			finishJob(pathPrincipal)
			clientsock.close()
			return
		
		except timeout:
			clientsock.send("\nTimeout!\n")
			clientsock.close()
			return
	
	except timeout:
		clientsock.send("\nTime limit exceeded for PoW!\n")
		clientsock.close()
		return

	
if __name__=='__main__':
	ADDR = (HOST, PORT)
	serversock = socket(AF_INET, SOCK_STREAM)
	serversock.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
	serversock.bind(ADDR)
	serversock.listen(1)
	while 1:
		clientsock, addr = serversock.accept()
		thread.start_new_thread(manipulador, (clientsock, addr))
		
		
		
